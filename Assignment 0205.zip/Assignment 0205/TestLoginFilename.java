package excelops;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import utils.CaptureScreenShot;

public class TestLoginFilename {

	static WebDriver driver;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		driver = new ChromeDriver();
		
		
		
		driver.get("https://the-internet.herokuapp.com/login");
		
		driver.findElement(By.id("username")).sendKeys("tomsmith");
		driver.findElement(By.id("password")).sendKeys("SuperSecord!");
	
		driver.findElement(By.cssSelector("#login > button")).click();
		try {
			driver.findElement(By.partialLinkText("Logout"));
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Login Failed.");
			UserPassAss fn= new UserPassAss();
			String filename = fn.FileNameForLogin("tomsmith", "SuperSecord!");
			
			System.out.println(filename);
			CaptureScreenShot cs = new CaptureScreenShot();
			cs.takeSnapShot(driver, filename);
		}

	}

}
