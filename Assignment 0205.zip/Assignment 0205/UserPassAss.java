package excelops;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class UserPassAss {

	public String FileNameForLogin(String u,String  p) {
		// TODO Auto-generated method stub
		
		
		String filename;
		
		LocalDateTime now = LocalDateTime.now();
		System.out.println("Before formatting: " + now);
		
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH-mm");
		filename = "C:\\Users\\Administrator\\Desktop\\" + u + "_" + p + "_" + now.format(format) + ".jpg";
		
		System.out.println("After formatting: " + filename);
		
		
		return (filename);
		

	
	}
}




